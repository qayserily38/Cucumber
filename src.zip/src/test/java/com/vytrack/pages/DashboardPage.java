package com.vytrack.pages;

public class DashboardPage extends BasePage {
}
